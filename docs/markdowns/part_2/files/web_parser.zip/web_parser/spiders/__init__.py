# Если импортировать подпакет вне my_package, 
# то будет доступно имя web_parser, 
# даже если мы не ссылаемся на spiders

from .web_parser import spider

