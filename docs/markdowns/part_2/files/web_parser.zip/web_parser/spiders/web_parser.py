######ВНИМАНИЕ! КОД НЕ ОТОБРАЖАЕТ РЕАЛЬНЫЙ SCRAPY######

## Здесь хранится ваш spider, с помощью которого вы описываете логику сбора данных

# Парсинг (Parsing) - сбор информации из источника
# Веб-скрейпинг (Web-scraping)- сбор информации со странички веб сайта
# Краулинг (Crawling) - сбор информации с многостраничного ресурса из нескольких источник

from ..settings import FEED_EXPORT_ENCODING

def spider(FEED_EXPORT_ENCODING=FEED_EXPORT_ENCODING):
    return f'"spider" function called with argument {FEED_EXPORT_ENCODING}'

