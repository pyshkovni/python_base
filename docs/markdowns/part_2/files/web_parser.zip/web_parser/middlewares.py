# Define here the models for your spider middleware
#
# See documentation in:
# https://docs.scrapy.org/en/latest/topics/spider-middleware.html
# useful for handling different item types with a single interface

from .settings import BOT_NAME, SPIDER_MODULES


def from_crawler(BOT_NAME=BOT_NAME):
    return f'"from-crawler" function called with argument {BOT_NAME}'


def process_spider_input():
    return '"process_spider_input" function called'


def spider_opened(SPIDER_MODULES=SPIDER_MODULES):
    return f'"spider_opened" function called with argument {SPIDER_MODULES}'
