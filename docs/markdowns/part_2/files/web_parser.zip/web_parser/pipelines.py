######ВНИМАНИЕ! КОД НЕ ОТОБРАЖАЕТ РЕАЛЬНЫЙ SCRAPY######

# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://docs.scrapy.org/en/latest/topics/item-pipeline.html


# useful for handling different item types with a single interface
from .settings import NEWSPIDER_MODULE


def process_item(NEWSPIDER_MODULE=NEWSPIDER_MODULE):
    return f'"process_item" function called with argument {NEWSPIDER_MODULE}'

