######ВНИМАНИЕ! КОД НЕ ОТОБРАЖАЕТ РЕАЛЬНЫЙ SCRAPY######

# Define here the models for your scraped items
#
# See documentation in:
# https://docs.scrapy.org/en/latest/topics/items.html

import .settings

def get_items()
    pass
